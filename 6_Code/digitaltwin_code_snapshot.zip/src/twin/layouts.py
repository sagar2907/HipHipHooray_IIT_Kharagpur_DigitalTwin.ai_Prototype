"""Line topologies for the layout-transfer experiment.

Four layouts differing in length, merge count and the presence of a
parallel station pair. The literature review found no published work
demonstrating bottleneck-predictor transfer across line layouts; these
four are the substrate for that experiment: train on some, test on the
rest, report the degradation honestly.

A `parallel` station is one logical operation executed by two servers
sharing a queue - the standard plant response to an operation that cannot
be sped up. It deliberately breaks the pure-series assumption that most
bottleneck detection implicitly relies on.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Layout:
    name: str
    n_spine: int
    merges: dict = field(default_factory=dict)     # spine idx (0-based) -> feeder length
    parallel: set = field(default_factory=set)     # spine idx with 2 servers
    # A 12-second spread (was 5) so one station is CLEARLY the slowest.
    # With 52-58 s the line had no dominant constraint: nine stations showed
    # positive marginal value and the "true bottleneck" label was decided by
    # differences of half a car, which is noise. A real line is balanced but
    # not perfectly - there is normally one station everyone knows is tight.
    ct_range: tuple = (50.0, 62.0)
    feeder_ct_range: tuple = (48.0, 58.0)


LAYOUTS = {
    "L1": Layout("L1", 20, merges={11: 3}),
    "L2": Layout("L2", 30, merges={9: 3, 21: 4}),
    "L3": Layout("L3", 20, merges={11: 3}, parallel={6}),
    "L4": Layout("L4", 15, merges={7: 2}),
}
