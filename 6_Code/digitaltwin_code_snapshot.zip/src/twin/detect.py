"""Bottleneck detection, second generation.

Built from the method worked out in review rather than from a single paper.
The chain of reasoning, and why each piece is here:

  1. Rank stations by PROCESSING time, not by how busy they look.
     Utilisation cannot separate a station that is slow from one that is
     merely never allowed to rest - both read ~95% busy. Processing time
     separates them immediately.

  2. Processing time means WORK, not dwell. The time a car spends at a
     station includes any wait caused by a full buffer downstream. Charging
     that wait to the station blames a victim for its neighbour's fault.
     Where station states exist we subtract it directly; where they do not
     we infer it from the neighbour signature (see infer_states_from_scans).

  3. Divide by availability. A station at 55 s that is broken 10% of the
     time needs 61 s per car in practice, which is worse than a reliable
     58 s station. Raw processing time ranks those backwards.

  4. Compare every station to ITS OWN baseline, never to takt. Takt is a
     target for the line and says nothing about whether one station is
     behaving normally. A station drifting 54 -> 57 s is abnormal even
     though it is still comfortably under a 60 s takt.

  5. Never judge from one car. Manual station times scatter widely - a
     single 68 s car on a 54 s station is normal noise, not a fault.
     Averaging shrinks that noise by sqrt(n), and CUSUM accumulates
     evidence so small drifts are caught without a fixed window.

  6. Report time-to-overtake, not just "abnormal". Gap to the current
     constraint divided by drift rate answers the question the brief
     actually asks: where is a bottleneck FORMING.

  7. Attach confidence and provenance. A directly measured value and an
     inferred one must never look identical to the operator.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from .events import Run, state_spans

WORK_STATES = ("working",)
DOWN_STATES = ("down",)
WAIT_STATES = ("blocked", "starved")
PAUSE_STATES = ("break",)

WINDOW_S = 1800          # trailing observation window
MIN_UNITS = 8            # below this the average is too noisy to rank on


# --------------------------------------------------------------------------
# Station state from scans alone (the dark-station case)
# --------------------------------------------------------------------------
def infer_states_from_scans(scans: pd.DataFrame, horizon_s: int,
                            baseline_ct: dict | None = None) -> pd.DataFrame:
    """Reconstruct blocked / starved / working from boundary scans only.

    The neighbour signature: if a station is the constraint, the station
    BEHIND it shows its dwell stretching past its own baseline (it has
    finished but cannot hand over - blocked), and the station AHEAD shows
    gaps between arrivals (nothing is reaching it - starved). Neither
    requires a sensor inside any station.

    Returns one row per (station, unit) with dwell, an estimate of the work
    portion, and the inferred state.
    """
    p = scans.pivot_table(index=["vin", "station_id"], columns="event",
                          values="t_s", aggfunc="first").dropna(
                              subset=["in", "out"]).reset_index()
    p["dwell"] = p["out"] - p["in"]
    p = p.sort_values(["station_id", "in"])

    # each station's own baseline = the fast end of its dwell distribution.
    # A car that passed through with no waiting is the cleanest observation
    # of pure work time available, so the low quantile approximates it.
    if baseline_ct is None:
        baseline_ct = p.groupby("station_id").dwell.quantile(0.15).to_dict()
    p["baseline"] = p.station_id.map(baseline_ct)
    p["excess"] = (p.dwell - p.baseline).clip(lower=0)

    # gap since the previous car arrived at this station -> starvation
    p["prev_out"] = p.groupby("station_id")["out"].shift(1)
    p["arrival_gap"] = (p["in"] - p["prev_out"]).clip(lower=0).fillna(0)

    p["work_est"] = p.dwell - p.excess
    p["state_hint"] = np.where(
        p.excess > 0.25 * p.baseline, "blocked",
        np.where(p.arrival_gap > 0.25 * p.baseline, "starved", "working"))
    return p[["vin", "station_id", "in", "out", "dwell", "baseline",
              "work_est", "arrival_gap", "state_hint"]]


# --------------------------------------------------------------------------
@dataclass
class StationReading:
    station: str
    units: int
    proc_time: float          # mean WORK seconds per unit
    availability: float
    effective_ct: float       # proc_time / availability - the ranking key
    blocked_share: float
    starved_share: float
    drift_cusum: float        # accumulated evidence of a shift vs baseline
    drift_rate: float         # seconds of processing time gained per hour
    provenance: str           # "measured" | "inferred"
    confidence: float


@dataclass
class Verdict:
    at_s: int
    ranking: list             # StationReading, worst (slowest) first
    constraint: str
    margin: float             # seconds between first and second
    confidence: float
    forming: list = field(default_factory=list)   # (station, minutes_to_overtake)
    cross_check_agrees: bool = True


class Detector:
    """Cascade detector: cheap ranking always, expensive work only on demand."""

    def __init__(self, run: Run, window_s: int = WINDOW_S,
                 use_states: bool = True):
        self.run = run
        self.window_s = window_s
        self.spans = state_spans(run.states, run.horizon_s) if use_states else {}
        self.use_states = use_states and bool(self.spans)
        self.stations = sorted(
            {s for s in (self.spans or {}) if s.startswith("S")}
            or {s for s in run.scans.station_id.unique() if s.startswith("S")})
        self.scan_view = infer_states_from_scans(run.scans, run.horizon_s)
        self.exits = (run.scans[run.scans.event == "out"]
                      .groupby("station_id").t_s.apply(np.sort).to_dict())
        self._baseline: dict[str, tuple] = {}

    # ---------------------------------------------------------------- window
    def _from_states(self, st: str, w0: int, w1: int):
        work = down = blocked = starved = pause = 0
        for a, b, v in self.spans.get(st, []):
            if b <= w0 or a >= w1:
                continue
            d = min(b, w1) - max(a, w0)
            if v in WORK_STATES:
                work += d
            elif v in DOWN_STATES:
                down += d
            elif v in WAIT_STATES:
                blocked += d if v == "blocked" else 0
                starved += d if v == "starved" else 0
            elif v in PAUSE_STATES:
                pause += d
        span = max(1, (w1 - w0) - pause)          # breaks are not the station's fault
        return work, down, blocked, starved, span

    def _from_scans(self, st: str, w0: int, w1: int):
        g = self.scan_view[(self.scan_view.station_id == st) &
                           (self.scan_view["out"] > w0) &
                           (self.scan_view["in"] < w1)]
        if g.empty:
            return 0.0, 0.0, 0.0, 0.0, max(1, w1 - w0)
        work = float(g.work_est.sum())
        blocked = float((g.dwell - g.work_est).sum())
        starved = float(g.arrival_gap.sum())
        return work, 0.0, blocked, starved, max(1, w1 - w0)

    def _units(self, st: str, w0: int, w1: int) -> int:
        a = self.exits.get(st)
        if a is None:
            return 0
        return int(np.searchsorted(a, w1) - np.searchsorted(a, w0))

    def read(self, at_s: int) -> list[StationReading]:
        w0, w1 = max(0, at_s - self.window_s), at_s
        out = []
        for st in self.stations:
            if self.use_states:
                work, down, blk, srv, span = self._from_states(st, w0, w1)
                prov = "measured"
            else:
                work, down, blk, srv, span = self._from_scans(st, w0, w1)
                prov = "inferred"
            units = self._units(st, w0, w1)
            if units < 1:
                continue
            proc = work / units
            avail = max(0.05, (span - down) / span)
            eff = proc / avail

            # baseline: the station's own early behaviour, learned once
            if st not in self._baseline:
                b0, b1 = 0, min(self.run.horizon_s, 2 * self.window_s)
                if self.use_states:
                    bw, bd, _, _, bs = self._from_states(st, b0, b1)
                else:
                    bw, bd, _, _, bs = self._from_scans(st, b0, b1)
                bu = max(1, self._units(st, b0, b1))
                self._baseline[st] = (bw / bu, max(0.05, (bs - bd) / bs))
            base_proc, base_av = self._baseline[st]
            sd = max(0.02 * base_proc, 0.5)
            cusum = max(0.0, (proc - base_proc) / sd - 0.5) * np.sqrt(units)

            out.append(StationReading(
                station=st, units=units, proc_time=proc, availability=avail,
                effective_ct=eff, blocked_share=blk / span,
                starved_share=srv / span, drift_cusum=cusum, drift_rate=0.0,
                provenance=prov,
                confidence=min(1.0, units / MIN_UNITS)))
        return out

    # ------------------------------------------------------------- verdict
    def verdict(self, at_s: int) -> Verdict | None:
        rd = self.read(at_s)
        rd = [r for r in rd if r.units >= 2]
        if len(rd) < 2:
            return None
        rd.sort(key=lambda r: r.effective_ct, reverse=True)
        top, second = rd[0], rd[1]
        margin = top.effective_ct - second.effective_ct

        # cross-check: the constraint should be the station least often
        # forced idle by a neighbour. Agreement raises confidence; a clash
        # is reported rather than hidden.
        idle = {r.station: r.blocked_share + r.starved_share for r in rd}
        agrees = min(idle, key=idle.get) == top.station

        # forming: gap to the constraint divided by drift rate
        forming = []
        prev = self.read(max(0, at_s - self.window_s))
        prevmap = {r.station: r.proc_time for r in prev}
        for r in rd[1:]:
            p0 = prevmap.get(r.station)
            if p0 is None or r.proc_time <= p0:
                continue
            rate = (r.proc_time - p0) / (self.window_s / 3600.0)   # s per hour
            gap = top.effective_ct - r.effective_ct
            if rate > 0.2 and gap / rate < 8:
                forming.append((r.station, round(60 * gap / rate)))
            r.drift_rate = rate
        forming.sort(key=lambda x: x[1])

        n = max(1e-6, np.mean([r.effective_ct for r in rd]))
        conf = float(np.clip(margin / (0.08 * n), 0, 1)) * (1.0 if agrees else 0.7)
        conf *= min(1.0, top.units / MIN_UNITS)

        return Verdict(at_s=at_s, ranking=rd, constraint=top.station,
                       margin=margin, confidence=round(conf, 3),
                       forming=forming[:3], cross_check_agrees=agrees)

    def timeline(self, step_s: int = 300):
        rows = []
        for at in range(self.window_s, self.run.horizon_s, step_s):
            v = self.verdict(at)
            if v is None:
                continue
            rows.append(dict(minute=at // 60, constraint=v.constraint,
                             second=v.ranking[1].station,
                             margin=round(v.margin, 2), confidence=v.confidence,
                             agrees=v.cross_check_agrees,
                             forming=";".join(f"{s}@{m}min" for s, m in v.forming)))
        return pd.DataFrame(rows)
