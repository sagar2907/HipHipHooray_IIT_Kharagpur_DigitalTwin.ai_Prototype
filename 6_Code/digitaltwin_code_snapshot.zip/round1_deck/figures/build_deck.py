#!/usr/bin/env python3
"""Fills the Accenture Round 1 template: deletes the instructions slide, writes the
three content slides with Arial text and the generated figures, adds an evidence slide."""

import copy
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN

SRC = "/sessions/stoic-festive-edison/mnt/uploads/AIC_Talent-Brand_PPT-Template (1).pptx"
OUT = "DigitalTwinAI_Assembly-Line-Twin.pptx"

INK = RGBColor(0x12, 0x17, 0x2B)
BODY = RGBColor(0x2B, 0x31, 0x47)
PURPLE = RGBColor(0x6B, 0x21, 0xC8)
TEAL = RGBColor(0x0F, 0x6E, 0x56)

HEADLINE_SZ = Pt(16)
BODY_SZ = Pt(11)


def set_text(tf, blocks, size=BODY_SZ, color=BODY, font="Arial"):
    """blocks = list of (text, bold, color_or_None)."""
    tf.word_wrap = True
    first = True
    for text, bold, col in blocks:
        para = tf.paragraphs[0] if first else tf.add_paragraph()
        first = False
        para.alignment = PP_ALIGN.LEFT
        para.space_after = Pt(7)
        run = para.add_run()
        run.text = text
        run.font.name = font
        run.font.size = size
        run.font.bold = bold
        run.font.color.rgb = col if col is not None else color


def clear_and_fill(slide, headline, paras, img, prs,
                   text_top=1.25, text_h=2.35, img_top=3.75, img_h=2.95):
    """Adds a headline, a body block and a full-width figure to a template slide."""
    left = Inches(0.55)
    width = Inches(12.25)

    hb = slide.shapes.add_textbox(left, Inches(text_top - 0.45), width, Inches(0.42))
    set_text(hb.text_frame, [(headline, True, PURPLE)], size=HEADLINE_SZ)

    tb = slide.shapes.add_textbox(left, Inches(text_top), width, Inches(text_h))
    set_text(tb.text_frame, paras)

    pic = slide.shapes.add_picture(img, left, Inches(img_top), width=width)
    if pic.height > Inches(img_h):
        scale = Inches(img_h) / pic.height
        pic.height = int(pic.height * scale)
        pic.width = int(pic.width * scale)
        pic.left = int((prs.slide_width - pic.width) / 2)


def duplicate_slide(prs, index):
    """Copies a slide (same layout) and appends it, then moves it after the source."""
    src = prs.slides[index]
    new = prs.slides.add_slide(src.slide_layout)
    for shp in src.shapes:
        new.shapes._spTree.insert_element_before(copy.deepcopy(shp._element), "p:extLst")
    xml_slides = prs.slides._sldIdLst
    ids = list(xml_slides)
    xml_slides.remove(ids[-1])
    xml_slides.insert(index + 1, ids[-1])
    return prs.slides[index + 1]


def drop_slide(prs, index):
    xml_slides = prs.slides._sldIdLst
    ids = list(xml_slides)
    rId = ids[index].get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id")
    prs.part.drop_rel(rId)
    xml_slides.remove(ids[index])


# ------------------------------------------------------------------ content

S4 = [("A vehicle line runs at the pace of its slowest station. When one station slips from 60 to 68 "
       "seconds, output falls from 60 to 52.9 vehicles per hour – 56 vehicles lost in a single shift. "
       "Stations behind it are blocked, stations ahead are starved, and the station responsible is the "
       "only one still running smoothly. It is the one place that looks normal.", False, None),
      ("The intuitive fix fails. We jammed a five-station line, repaired it, then made the slow station "
       "twice as fast. Output was identical: 106 cars either way. The queue simply relocated downstream "
       "within five minutes.", False, None),
      ("Quality fails the same way. Tools drift before they break, so defects surface at end-of-line "
       "testing dozens of vehicles later. Worse, monitoring watches the channel that is lying: a drifting "
       "torque sensor let 11,631 defective joints – 98% of all defects – pass as OK, because the "
       "reading barely moved while true clamp force collapsed.", False, None),
      ("Both failures share one cause: the plant's own instruments point at the wrong thing. The plant "
       "manager loses output nobody can explain; the quality manager ships defects that surface as "
       "warranty months later.", True, INK)]

S5 = [("The twin is a discrete-event model of the line, calibrated from the event stream the plant already "
       "emits – barcode scans, PLC tags, tool controllers. It runs alongside the line, estimates what is "
       "not measured, ranks the actions available now, and re-calibrates whenever twin drift, the "
       "divergence between predicted and observed throughput, exceeds threshold. The plant team decides. "
       "The twin never writes to line control.", False, None),
      ("Three technical choices define it. Rank by effective processing time – work divided by "
       "availability – never by utilisation; a heavily fed station and an intrinsically slow one both "
       "read 95% busy. Detect drift on every channel, then classify the failure mode, because a worn tool "
       "and a lying sensor look identical on torque alone and need opposite fixes. For stations with no "
       "sensors, bracket them using the scanners either side, then use neighbour states to separate "
       "working from waiting.", False, None),
      ("We deliberately build no 3D rendering, write nothing back to line control, and require no new "
       "hardware.", False, None),
      ("A dashboard shows what happened. The twin shows what would happen under each action available "
       "right now – including that speeding up the slow station recovers nothing.", True, INK)]

S6 = [("We build the simulated plant as well as the twin, so warning time is measured, not claimed. A fault "
       "is injected at a known moment; we record when the twin alerts, when a conventional KPI would "
       "reveal it, and when end-of-line testing would finally catch it.", False, None),
      ("Measured so far. Drift warning arrives 421 to 1,322 vehicles before sustained scrap, on held-out "
       "calibration. On strong constraints the twin identifies the right station 46.0% of the time, 57.9% "
       "within two, against 35.1% and 48.0% for utilisation ranking. On a balanced line every method falls "
       "to 13–15%, and utilisation to 8.6% – which is the correct answer, because a balanced line "
       "has no dominant constraint. A bad fastener lot made 21 of 23 tools alarm together and none "
       "elsewhere. Bracketing bias at dark stations is quantified: 88.8 seconds observed against 58.0 "
       "seconds of true work, a 53% overstatement.", False, None),
      ("We will not claim a blended accuracy figure, guaranteed false-alarm rates, or invention of the "
       "primitives – active period is Roser 2001, CUSUM is Page 1954, Theory of Constraints is Goldratt "
       "1984.", False, None),
      ("We caught ourselves grading our own homework six times. Every number here is post-fix.", True, INK)]


def main():
    prs = Presentation(SRC)

    # slide 6 (Video) -> duplicate its layout for the evidence slide, placed after slide 5
    evidence = duplicate_slide(prs, 4)          # index 4 = slide 5 (Proposed solution)
    for shp in list(evidence.shapes):
        if shp.has_text_frame and "Proposed solution" in shp.text_frame.text:
            shp.text_frame.text = "Why it matters, and how we prove it"
            for p in shp.text_frame.paragraphs:
                for r in p.runs:
                    r.font.name = "Arial"
                    r.font.size = Pt(20)
                    r.font.bold = True
                    r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)

    clear_and_fill(prs.slides[3], "The station causing the loss is the one place that looks normal.",
                   S4, "fig1_blocking_starving.png", prs,
                   text_top=1.50, text_h=1.95, img_top=3.55, img_h=3.05)
    clear_and_fill(prs.slides[4], "A correction layer, not another dashboard.",
                   S5, "fig2_closed_loop.png", prs,
                   text_top=1.50, text_h=2.45, img_top=4.05, img_h=2.65)
    clear_and_fill(prs.slides[5], "Early warning is measured, not claimed.",
                   S6, "fig4_timeline.png", prs,
                   text_top=1.50, text_h=2.45, img_top=4.05, img_h=2.65)

    drop_slide(prs, 1)                          # remove the instructions slide

    prs.save(OUT)
    print("saved:", OUT)
    p2 = Presentation(OUT)
    for i, s in enumerate(p2.slides, 1):
        first = ""
        for sh in s.shapes:
            if sh.has_text_frame and sh.text_frame.text.strip():
                first = sh.text_frame.text.strip().split("\n")[0][:58]
                break
        print("  slide %d  %-46s shapes=%d" % (i, first, len(s.shapes)))


if __name__ == "__main__":
    main()
