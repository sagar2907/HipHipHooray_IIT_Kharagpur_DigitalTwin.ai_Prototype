#!/usr/bin/env python3
"""Generates the three slide figures as wide PNG strips for the Accenture template."""

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle
import matplotlib.patheffects as pe

plt.rcParams["font.family"] = "DejaVu Sans"

INK = "#12172B"
BODY = "#2B3147"
MUTED = "#6E7488"
PURPLE = "#A100FF"
PURPLE_D = "#6B21C8"
PURPLE_L = "#F1E6FF"
TEAL = "#0F6E56"
TEAL_L = "#DDF1EE"
AMBER = "#B87608"
AMBER_L = "#FBEED6"
RED = "#C0392B"
RED_L = "#FAE5E2"
GREY = "#9AA0B0"
GREY_L = "#F1F1F4"

W, H, DPI = 12.2, 2.95, 200


def newfig():
    fig, ax = plt.subplots(figsize=(W, H), dpi=DPI)
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 24)
    ax.axis("off")
    fig.patch.set_alpha(0)
    return fig, ax


def box(ax, x, y, w, h, fc, ec, lw=1.6, r=0.5, ls="-"):
    ax.add_patch(FancyBboxPatch((x, y), w, h,
                 boxstyle="round,pad=0,rounding_size=%.2f" % r,
                 facecolor=fc, edgecolor=ec, linewidth=lw, linestyle=ls))


def txt(ax, x, y, s, size=8, color=INK, weight="normal", ha="center", va="center", style="normal"):
    ax.text(x, y, s, fontsize=size, color=color, fontweight=weight,
            ha=ha, va=va, style=style)


def arrow(ax, x1, y1, x2, y2, color=GREY, lw=1.6, style="-|>", ls="-"):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle=style,
                 mutation_scale=13, color=color, linewidth=lw, linestyle=ls,
                 shrinkA=0, shrinkB=0))


# --------------------------------------------------------------- figure 1
def fig1():
    fig, ax = newfig()
    names = [("Station 1", "60 s", "BLOCKED", AMBER_L, AMBER),
             ("Station 2", "60 s", "BLOCKED", AMBER_L, AMBER),
             ("Station 3", "68 s", "WORKING", RED_L, RED),
             ("Station 4", "60 s", "STARVED", GREY_L, GREY),
             ("Station 5", "60 s", "STARVED", GREY_L, GREY)]
    bw, gap = 15.0, 4.2
    x0 = (100 - (5 * bw + 4 * gap)) / 2.0
    for i, (n, cyc, st, fc, ec) in enumerate(names):
        x = x0 + i * (bw + gap)
        if i < 2:
            for q in range(3 - i):
                box(ax, x + 4.2, 18.4 + q * 1.7, 6.6, 1.25, AMBER_L, AMBER, lw=1.0, r=0.2)
        box(ax, x, 9.6, bw, 7.2, fc, ec)
        txt(ax, x + bw / 2, 14.6, n, 10.5, INK, "bold")
        txt(ax, x + bw / 2, 12.6, cyc, 9.5, MUTED)
        txt(ax, x + bw / 2, 10.8, st, 8.2, ec, "bold")
        if i < 4:
            arrow(ax, x + bw + 0.4, 13.2, x + bw + gap - 0.4, 13.2, GREY, 1.5)
    cx = x0 + 2 * (bw + gap) + bw / 2.0
    for i in (0, 1):
        sx = x0 + i * (bw + gap) + bw / 2.0
        arrow(ax, sx, 8.4, cx - 6.0, 6.4, AMBER, 1.7)
    for i in (3, 4):
        sx = x0 + i * (bw + gap) + bw / 2.0
        arrow(ax, sx, 8.4, cx + 6.0, 6.4, GREY, 1.7)
    box(ax, cx - 26, 2.4, 52, 3.6, "#FFFFFF", RED, lw=1.8)
    txt(ax, cx, 4.2, "the constraint  -  never blocked, never starved", 11, RED, "bold")
    txt(ax, x0, 0.8, "blocking points forward", 8.5, AMBER, "bold", ha="left")
    txt(ax, x0 + 5 * bw + 4 * gap, 0.8, "starving points backward", 8.5, MUTED, "bold", ha="right")
    fig.savefig("fig1_blocking_starving.png", dpi=DPI, bbox_inches="tight",
                transparent=True, pad_inches=0.02)
    plt.close(fig)


# --------------------------------------------------------------- figure 2
def fig2():
    fig, ax = newfig()
    steps = [("Real line", "observe", GREY_L, GREY, False),
             ("Unified\nstate", "+ provenance", PURPLE_L, PURPLE_D, False),
             ("Digital twin", "kept in step", PURPLE_L, PURPLE_D, False),
             ("Ranked\nactions", "with evidence", PURPLE_L, PURPLE_D, False),
             ("PLANT TEAM\nDECIDES", "human in the loop", TEAL_L, TEAL, True),
             ("Observe\noutcome", "twin-drift check", GREY_L, GREY, False)]
    bw, gap = 14.4, 2.6
    x0 = (100 - (6 * bw + 5 * gap)) / 2.0
    for i, (n, sub, fc, ec, hl) in enumerate(steps):
        x = x0 + i * (bw + gap)
        box(ax, x, 10.4, bw, 7.6, fc, ec, lw=2.2 if hl else 1.6)
        txt(ax, x + bw / 2, 15.3 if "\n" in n else 15.1, n, 9.4 if hl else 9.2,
            INK, "bold")
        txt(ax, x + bw / 2, 11.7, sub, 7.4, ec if hl else MUTED,
            "bold" if hl else "normal")
        if i < 5:
            arrow(ax, x + bw + 0.25, 14.2, x + bw + gap - 0.25, 14.2, PURPLE_D, 1.7)
    lx = x0 + bw / 2 + bw
    rx = x0 + 5 * (bw + gap) + bw / 2.0
    ax.plot([rx, rx], [10.4, 7.0], color=PURPLE_D, lw=1.7, ls=(0, (4, 2)))
    ax.plot([rx, lx], [7.0, 7.0], color=PURPLE_D, lw=1.7, ls=(0, (4, 2)))
    arrow(ax, lx, 7.0, lx, 10.2, PURPLE_D, 1.7, ls=(0, (4, 2)))
    txt(ax, (lx + rx) / 2, 5.8, "re-calibrate when twin drift exceeds threshold",
        9, PURPLE_D, "bold")
    box(ax, 50 - 30, 1.2, 60, 3.2, "#FFFFFF", TEAL, lw=1.6)
    txt(ax, 50, 2.8, "the twin advises  -  it never writes to line control", 10.5, TEAL, "bold")
    fig.savefig("fig2_closed_loop.png", dpi=DPI, bbox_inches="tight",
                transparent=True, pad_inches=0.02)
    plt.close(fig)


# --------------------------------------------------------------- figure 4
def fig4():
    fig, ax = newfig()
    y = 12.5
    ax.plot([6, 95], [y, y], color=GREY, lw=2.0, zorder=1)
    arrow(ax, 93, y, 96.5, y, GREY, 2.0)
    marks = [(10, "T0", "fault injected", "known exactly", TEAL),
             (34, "T1", "twin alerts", "the number that matters", PURPLE_D),
             (62, "T2", "conventional KPI", "a human could now see it", AMBER),
             (88, "T3", "end-of-line catches it", "current practice", RED)]
    for x, tag, lab, note, col in marks:
        ax.plot([x, x], [y - 2.4, y + 2.4], color=col, lw=2.0, zorder=2)
        ax.add_patch(Circle((x, y), 0.85, facecolor=col, edgecolor=col, zorder=3))
        txt(ax, x, y + 4.2, tag, 12, col, "bold")
        txt(ax, x, y - 3.9, lab, 9.4, INK, "bold")
        txt(ax, x, y - 5.6, note, 8.2, MUTED)
    box(ax, 34, 18.6, 62 - 34, 2.9, PURPLE_L, PURPLE_D, lw=1.6)
    txt(ax, 48, 20.05, "LEAD TIME", 10, PURPLE_D, "bold")
    box(ax, 10, 18.6, 34 - 10, 2.9, GREY_L, GREY, lw=1.2)
    txt(ax, 22, 20.05, "detection delay", 9, MUTED)
    txt(ax, 50, 1.4,
        "Because the plant is ours, T0 is known exactly - so lead time is measured, not asserted",
        10, INK, "bold")
    fig.savefig("fig4_timeline.png", dpi=DPI, bbox_inches="tight",
                transparent=True, pad_inches=0.02)
    plt.close(fig)


if __name__ == "__main__":
    fig1(); fig2(); fig4()
    print("wrote fig1_blocking_starving.png, fig2_closed_loop.png, fig4_timeline.png")
